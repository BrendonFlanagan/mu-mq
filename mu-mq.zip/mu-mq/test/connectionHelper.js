/* global describe, it beforeEach afterEach */
/* eslint-disable no-unused-expressions */
'use strict'
try {
  const chai = require('chai')
  const expect = chai.expect
  const assert = chai.assert

  const ConnectionHelper = require('../lib/connectionHelper')
  let connectionHelper = null
  const APPLICATION_CONFIG = require('../lib/application-config')
  let reqOpts = null
  let connectionObject

  /* These mock tests for now require both the ibmmq node module and an active queue manager with a set of defined queues
  and channel per the application-config config.

  In future sinon & mock-require could be used to simulate the ibmmq node module functions so therefore no physical
  infrastructure would be required in order to test this functionality. */

  describe('connectionHelper', () => {
    // Things we want in place as defaults before each test, then, each test can alter if need be.
    beforeEach(function () {
      try {
        connectionHelper = new ConnectionHelper()
        reqOpts = {
          host: APPLICATION_CONFIG.mqHost,
          channel: APPLICATION_CONFIG.mqConnChannel,
          qMgr: APPLICATION_CONFIG.mqQueueManager,
          mqOptions: APPLICATION_CONFIG.mqOptions
        }
      } catch (err) {

      }
    })

    // Cleanup after each test
    afterEach(async function () {
      try {
        // Close any successfull open connections so next test is in a clean state.
        await connectionHelper.mqClientClose(connectionObject)
      } catch (err) {
        // Don't worry about any errors, for example closing a connetion that is not open will error
        // since the test in question was suppose to not open a connection.
      }
    })

    describe('mqClientOpen', () => {
      it('mqClientOpen - Should return success', async () => {
        // connectionObject used in the mqClientClose test.
        assert.isObject(connectionObject = await connectionHelper.mqClientOpen(reqOpts))
      })
      it('mqClientOpen - Should return failure for incorrect host', async () => {
        reqOpts.host = 'abc.com'
        try {
          await connectionHelper.mqClientOpen(reqOpts)
        } catch (e) {
          expect(e.message).to.be.equals('CONNX: MQCC = MQCC_FAILED [2] MQRC = MQRC_HOST_NOT_AVAILABLE [2538]')
        }
      })
      it('mqClientOpen - Should return failure for incorrect qmgr', async () => {
        reqOpts.qMgr = 'xxx'
        try {
          await connectionHelper.mqClientOpen(reqOpts)
        } catch (e) {
          expect(e.message).to.be.equals('CONNX: MQCC = MQCC_FAILED [2] MQRC = MQRC_Q_MGR_NAME_ERROR [2058]')
        }
      })
      it('mqClientOpen - Should return failure for incorrect channel', async () => {
        reqOpts.channel = 'whatchannel'
        try {
          await connectionHelper.mqClientOpen(reqOpts)
        } catch (e) {
          expect(e.message).to.be.equals('CONNX: MQCC = MQCC_FAILED [2] MQRC = MQRC_UNKNOWN_CHANNEL_NAME [2540]')
        }
      })
      it('mqClientOpen - Should return failure for no channel', async () => {
        reqOpts.channel = null
        try {
          await connectionHelper.mqClientOpen(reqOpts)
        } catch (e) {
          expect(e.message).to.be.equals('CONNX: MQCC = MQCC_FAILED [2] MQRC = MQRC_CD_ERROR [2277]')
        }
      })
      it('mqClientOpen - Should return error for incorrect channel connection options', async () => {
        reqOpts.mqOptions.connectionOptions = 111
        try {
          await connectionHelper.mqClientOpen(reqOpts)
        } catch (e) {
          expect(e.message).to.be.equals('CONNX: MQCC = MQCC_FAILED [2] MQRC = MQRC_OPTIONS_ERROR [2046]')
        }
        // For some reason have to explicity set this back to a valid value, otherwise the mqClientClose - Should return success test
        // won't pass and will error out with invalid options, which is correct, as previous test had set that.
        reqOpts.mqOptions.connectionOptions = 2048
      })
    })

    // think need to turn this into a sequential process as somehow acting in async mode.
    describe('mqClientClose', () => {
      it('mqClientClose - Should return success', async () => {
        connectionObject = await connectionHelper.mqClientOpen(reqOpts)
        expect(await connectionHelper.mqClientClose(connectionObject)).to.be.true
      })
      it('mqClientClose - Should return error for trying to close the same connection twice', async () => {
        try {
          await connectionHelper.mqClientClose(connectionObject)
        } catch (e) {
          expect(e.message).to.be.equals('DISC: MQCC = MQCC_FAILED [2] MQRC = MQRC_HCONN_ERROR [2018]')
        }
      })
    })
  })
} catch (err) {
  console.log(err)
}

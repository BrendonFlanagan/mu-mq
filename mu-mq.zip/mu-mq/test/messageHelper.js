/* global describe, it before after */
'use strict'
try {
  const chai = require('chai')
  const expect = chai.expect
  const assert = chai.assert

  const ConnectionHelper = require('../lib/connectionHelper')
  const QueueHelper = require('../lib/queueHelper')
  const MessageHelper = require('../lib/messageHelper')
  let connectionHelper = null
  let queueHelper = null
  let messageHelper = null
  const APPLICATION_CONFIG = require('../lib/application-config')
  let reqOpts = null

  /* These mock tests for now require both the ibmmq node module and an active queue manager with a set of defined queues
  and channel per the application-config config.

  In future sinon & mock-require could be used to simulate the ibmmq node module functions so therefore no physical
  infrastructure would be required in order to test this functionality. */

  describe('messageHelper', () => {
    // Things we want in place as defaults for all tests, so open a MQ Client Connection, Open a Queue.
    before(async function () {
      connectionHelper = new ConnectionHelper()
      queueHelper = new QueueHelper()
      messageHelper = new MessageHelper()
      reqOpts = {
        host: APPLICATION_CONFIG.mqHost,
        channel: APPLICATION_CONFIG.mqConnChannel,
        qMgr: APPLICATION_CONFIG.mqQueueManager,
        requestQueue: APPLICATION_CONFIG.mqRequestQueue,
        replyQueue: APPLICATION_CONFIG.mqReplyQueue,
        mqOptions: APPLICATION_CONFIG.mqOptions
      }
      connectionObject = await connectionHelper.mqClientOpen(reqOpts)
      requestQueueObject = await queueHelper.mqOpenRequestQueue(connectionObject, reqOpts)
      replyQueueObject = await queueHelper.mqOpenReplyQueue(connectionObject, reqOpts)
    })

    // Cleanup after each test.
    after(async function () {
      try {
        await queueHelper.mqCloseQueue(requestQueueObject)
        await connectionHelper.mqClientClose(connectionObject)
      } catch (err) {
        // Don't worry about any errors, for example closing a connetion that is not open will error
        // since the test in question was suppose to not open a connection.
      }
    })

    let connectionObject = null
    let requestQueueObject = null
    let replyQueueObject = null

    /* NOTE NOTE NOTE - For the get to work, requires an app on other end that will pickup the request, process etc
      and send a response which follows mq request reply pattern of put msgid to correlid with new msgid.
      Said app could be an instance of an app that uses this library to do a get followed by put.

      At time of writing this, MAOT which is a free tool provided by IBM was used instead.    Which is a xml declared wrapper language
      around the actual IBM MQ libs and is therefore independent of any node module because it does not use any node code.
      */
    describe('mqPut - Request & Reply case', () => {
      let requestMQMD = null
      it('mqPut - Should return success', async () => {
        const data = 'abcd'
        assert.isObject(requestMQMD = await messageHelper.mqPut(requestQueueObject, data, reqOpts))
      })
      it('mqGet - Should get reply and CorrelId of reply should match MsgId of request', async () => {
        const response = await messageHelper.mqGet(replyQueueObject, requestMQMD, reqOpts)
        expect(response.body).to.be.equals(response.body)
        expect(requestMQMD.MsgId).to.be.equals(response.replyMQMD.CorrelId)
      })
      it('mqGet - Should error as message was already got', async () => {
        try {
          assert.isObject(await messageHelper.mqGet(replyQueueObject, requestMQMD, reqOpts))
        } catch (e) {
          expect(e.message).to.be.equals('GET: MQCC = MQCC_FAILED [2] MQRC = MQRC_NO_MSG_AVAILABLE [2033]')
        }
      })
      it('mqPut - Should return failure since queue got closed', async () => {
        const data = 'abcd'
        await queueHelper.mqCloseQueue(requestQueueObject)
        try {
          await messageHelper.mqPut(requestQueueObject, data, reqOpts)
        } catch (e) {
          expect(e.message).to.be.equals('PUT: MQCC = MQCC_FAILED [2] MQRC = MQRC_HOBJ_ERROR [2019]')
        }
      })
      it('mqPut - Should return failure for trying to put to wrong queue', async () => {
        const data = 'abcd'
        reqOpts.requestQueue = 'aa'
        try {
          await messageHelper.mqPut(requestQueueObject, data, reqOpts)
        } catch (e) {
          expect(e.message).to.be.equals('PUT: MQCC = MQCC_FAILED [2] MQRC = MQRC_HOBJ_ERROR [2019]')
        }
      })
    })
  })
} catch (err) {
  console.log(err)
}

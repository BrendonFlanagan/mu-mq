/* global describe, it before after */
/* eslint-disable no-unused-expressions */
'use strict'
try {
  const chai = require('chai')
  const expect = chai.expect
  const assert = chai.assert

  const ConnectionHelper = require('../lib/connectionHelper')
  const QueueHelper = require('../lib/queueHelper')
  let connectionHelper = null
  let queueHelper = null
  const APPLICATION_CONFIG = require('../lib/application-config')
  let reqOpts = null
  let connectionObject

  /* These mock tests for now require both the ibmmq node module and an active queue manager with a set of defined queues
  and channel per the application-config config.

  In future sinon & mock-require could be used to simulate the ibmmq node module functions so therefore no physical
  infrastructure would be required in order to test this functionality. */

  describe('queueHelper', () => {
    // Things we want in place as defaults before each test for all tests.   Being in this case the MQ Client Connection.
    before(async function () {
      connectionHelper = new ConnectionHelper()
      queueHelper = new QueueHelper()
      reqOpts = {
        host: APPLICATION_CONFIG.mqHost,
        channel: APPLICATION_CONFIG.mqConnChannel,
        qMgr: APPLICATION_CONFIG.mqQueueManager,
        requestQueue: APPLICATION_CONFIG.mqRequestQueue,
        replyQueue: APPLICATION_CONFIG.mqReplyQueue,
        mqOptions: APPLICATION_CONFIG.mqOptions
      }
      connectionObject = await connectionHelper.mqClientOpen(reqOpts)
    })

    // Cleanup after all tests.
    after(async function () {
      try {
        await connectionHelper.mqClientClose(connectionObject)
      } catch (err) {
        // Don't worry about any errors, for example closing a connetion that is not open will error
        // since the test in question was suppose to not open a connection.
      }
    })

    let requestQueueObject = null
    let replyQueueObject = null
    describe('mqOpenRequestQueue', () => {
      it('mqOpenRequestQueue - Should return success', async () => {
        assert.isObject(requestQueueObject = await queueHelper.mqOpenRequestQueue(connectionObject, reqOpts))
      })
      it('mqOpenRequestQueue - Should return failure for a gueue not found', async () => {
        reqOpts.requestQueue = 'xxx'
        try {
          await queueHelper.mqOpenRequestQueue(connectionObject, reqOpts)
        } catch (e) {
          expect(e.message).to.be.equals('OPEN: MQCC = MQCC_FAILED [2] MQRC = MQRC_UNKNOWN_OBJECT_NAME [2085]')
        }
      })
    })
    describe('mqOpenRelyQueue', () => {
      it('mqOpenRelyQueue - Should return success', async () => {
        assert.isObject(replyQueueObject = await queueHelper.mqOpenReplyQueue(connectionObject, reqOpts))
      })
      it('mqOpenReplyQueue - Should return failure for a gueue not found', async () => {
        reqOpts.replyQueue = 'xxx'
        try {
          await queueHelper.mqOpenReplyQueue(connectionObject, reqOpts)
        } catch (e) {
          expect(e.message).to.be.equals('OPEN: MQCC = MQCC_FAILED [2] MQRC = MQRC_UNKNOWN_OBJECT_NAME [2085]')
        }
      })
    })

    describe('mqCloseRequestQueue', () => {
      it('mqCloseRequestQueue - Should return success', async () => {
        expect(await queueHelper.mqCloseQueue(requestQueueObject)).to.be.true // eslint-ignore
      })
      it('mqCloseRequestQueue - Should return failure for a gueue not found', async () => {
        try {
          await queueHelper.mqCloseQueue(requestQueueObject)
        } catch (e) {
          expect(e.message).to.be.equals('CLOSE: MQCC = MQCC_FAILED [2] MQRC = MQRC_HOBJ_ERROR [2019]')
        }
      })
    })
    describe('mqCloseRelyQueue', () => {
      it('mqCloseRelyQueue - Should return success', async () => {
        expect(await queueHelper.mqCloseQueue(replyQueueObject)).to.be.true
      })
      it('mqCloseReplyQueue - Should return failure for a gueue not found', async () => {
        try {
          await queueHelper.mqCloseQueue(replyQueueObject)
        } catch (e) {
          expect(e.message).to.be.equals('CLOSE: MQCC = MQCC_FAILED [2] MQRC = MQRC_HOBJ_ERROR [2019]')
        }
      })
    })
  })
} catch (err) {
  console.log(err)
}

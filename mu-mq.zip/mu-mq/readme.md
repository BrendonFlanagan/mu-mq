## Purpose
The MQ Connector module provides a simple to use MQ client wrapper around the IMBMQ node module for doing MQ related tasks.
To start off with, the basic functionaly has only been wrapped.   Connect, Open, Get, Put, Close, Disconnect.

In future PUT can be replaced with PUT1 which will automatically handle the Open, Put, Close all in one invocation.   Put1 is a IBM MQ capability that is already expposed in the IBMMQ node module that this module wraps.

It also provides Open Tracing support and automated audit logging of the request and response.

It uses IBMMQ internally.


## Installation
```
$ npm install mu-mq
```

## Usage
Typical usage is to open a connection for the duration of the messaging, ie there is no point (as adds unnecessary overhead) openeing and closing a connection all the time, so keep the connection open as much as possible.

Then, you can open a queue or queues, put and get messages as much as you like.   But, its also typical practice for a MQ Client to only open a queue fo the duration of a singular message, as this frees up MQ Server resources when no messaging is occuring.

```javascript
require mqConnectionHelper = require('mu-mq').connectionHelper
require queueHelper = require('mu-mq').queueHelper
require messageHelper = require('mu-mq').messageHelper

```
TBD how to use once do a working example.


## How to include as a local module
STEP 1: In module project, execute npm pack:
This will build a <package-name>-<version>.tar.gz file.

STEP 2: Move the file to the consumer project
Ideally you can put all such files in a tmp folder in your consumer-project root:

STEP 3: Refer it in your package.json:
"dependencies": {
  "my-package": "file:/./tmp/my-package-1.3.3.tar.gz"
}
STEP 4: Install the packages:
npm install


## Installing
pre-req: node v14 or above

Requires node-gyp and then run node-gyp rebuild (has to go out to the internet to do things) while got internet access (so export http_proxy & https_proxy to http://localhost:3128) by using cntlm

Then unset these before trying npm install of this package.

## Contributors

[Brendon Flanagan][flanagb]

[flanagb]: mailto:brendon.flanagan@anz.com

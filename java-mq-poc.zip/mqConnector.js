var java = require("java");
java.classpath.push("commons-lang3-3.1.jar");
java.classpath.push("commons-io.jar");
java.classpath.push("lib/MQ/com.ibm.mq.jar")
java.classpath.push("lib/MQ/connector.jar")
java.classpath.push("lib/MQ/com.ibm.mq.jmqi.jar")


let MQQueueManager = java.import("com.ibm.mq.MQQueueManager")
let qmgrName = '10.106.202.235(1414)'
let queueManager = new MQQueueManager(qmgrName);


var list1 = java.newInstanceSync("java.util.ArrayList");
console.log(list1.sizeSync()); // 0
list1.addSync('item1');
console.log(list1.sizeSync()); // 1
 
java.newInstance("java.util.ArrayList", function(err, list2) {
  list2.addSync("item1");
  list2.addSync("item2");
  console.log(list2.toStringSync()); // [item1, item2]
});
 
var ArrayList = java.import('java.util.ArrayList');
var list3 = new ArrayList();
list3.addSync('item1');
list3.equalsSync(list1); // true
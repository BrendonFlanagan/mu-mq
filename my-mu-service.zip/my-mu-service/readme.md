# My First Mu Service
Mu service that returns "Hello Mu"

## Token Validation

To extract the JWT token from http header and validate the issuer, signature, expiry and scope.

Usage

```javascript
//add this block to config.js
  security: {
    authJWT: {
      securitySchemeName: 'OAuth2StatelessToken',
      issuers: getIssuerConfig(),
    },
  }

```

```bash
#set JWT_ISSUER_MAP environment var
export JWT_ISSUER_MAP='[{"name":"cartman-v1-union","jwksUrl":"https://cartman-v1-union.caas.nz.service.test/cartman-1.0/public-keys","algorithms":["RS512"]}]'

```

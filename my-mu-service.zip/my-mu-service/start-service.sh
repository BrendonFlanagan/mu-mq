#!/bin/bash -e
echo "Setting the JWT_ISSUER_MAP"

export JWT_ISSUER_MAP='[{"name":"cartman-v1-union","jwksUrl":"https://cartman-v1-union.caas.nz.service.test/cartman-1.0/public-keys","algorithms":["RS512"]}]'

echo "Starting the service"
node_modules/.bin/mu-server ./lib/api.yaml ./lib/config.js ./lib/handlers

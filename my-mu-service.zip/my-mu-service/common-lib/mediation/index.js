const httpConnector = require('@mu-eis/mu-connector-http')

const ServiceError = require('../error/ServiceError')

const callMediationApi = async function (ctx, opts) {
  let { req } = ctx
  let { config } = req.app.locals
  let props = config.envProperties

  const { name = 'med-api', method = 'get', url, query, headers = {}, body: reqBody, timeout = 10000 } = opts

  const standardApicHeaders = {
    'X-IBM-Client-Id': props.API_CLIENT_ID,
    Authorization: req.headers.authorization,
  }
  const combinedHeaders = { ...standardApicHeaders, ...headers }

  let reqOpts = {
    name,
    method,
    baseUrl: props.API_ENDPOINT,
    url,
    query,
    headers: combinedHeaders,
    body: reqBody,
    timeout,
  }

  let { error, status, body } = await httpConnector(reqOpts, ctx)

  if (error) {
    throw new ServiceError('Error while calling Mediation API', {
      id: 'MEDIATION_API_ERR',
      debug: { cause: error },
    })
  }

  if (status !== 200) {
    throw new ServiceError('Non 2xx response from Mediation API', {
      id: 'MEDIATION_API_ERR',
      debug: { status },
    })
  }

  return body
}

module.exports = { callMediationApi }

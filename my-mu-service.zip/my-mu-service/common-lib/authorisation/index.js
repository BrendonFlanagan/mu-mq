const httpConnector = require('@mu-eis/mu-connector-http')
// const debug = require('debug')('authorisation-service')
const ServiceError = require('../error/ServiceError')

const constants = {
  CUST_TYPE_PERSON: 'person',
  CUST_TYPE_ORG: 'organisation',
}
let internal = {}

internal.getAuthorisation = async function (context, arid) {
  let { req } = context
  let { config } = req.app.locals
  let props = config.envProperties
  let timeout = parseInt(process.env.AUTH_SVC_TIMEOUT, 10) || 10000

  let reqOpts = {
    name: 'get-auth',
    method: 'get',
    baseUrl: props.AUTH_ENDPOINT,
    url: `/api/authorisations/${arid}`,
    headers: {
      Authorization: req.headers.authorization,
      accept: 'application/json; version=2',
    },
    timeout,
  }
  let { error, status, body } = await httpConnector(reqOpts, context)

  if (error) {
    throw new ServiceError('Error while calling Authorisation service', {
      id: 'AUTH_SVC_ERR',
      debug: { cause: error },
    })
  }
  if (status !== 200) {
    throw new ServiceError('Non 2xx response from Authorisation service', {
      id: 'AUTH_SVC_ERR',
      debug: { status },
    })
  }
  return body
}

internal.getCustomersToInform = function (account, authToken) {
  let customers = []

  let individualOwners = account.accountOwnership.filter((c) => c.customerType === 'INDIVIDUAL')

  let initiatingCustomer = {
    authorisingType: 'INITIATOR',
    crn: authToken.crns[0],
    uuid: authToken.sub,
    capCisId: individualOwners.find((c) => c.isInitiatingCustomer).customerId,
  }

  // initiator ALWAYS gets event with inscope accounts
  customers.push(initiatingCustomer)

  // SOLELY OWNED ACCOUNT
  if (individualOwners.length === 1) {
    return customers
  }


  // JOINTLY OWNED ACCOUNT

  // If at least one customer has retracted auth
  // (initiator likely wasn't the one retracting - confirm this)
  // OJAH doesn't need event at all
  // don't include OJAH in customers-to-inform for this account
  if (account.customersRetractingApproval && account.customersRetractingApproval.length > 0) {
    return customers
  }


  let ojahUuid = account.customersThatHaveAuthorised.find((u) => u !== initiatingCustomer.uuid)

  // If OJAH has removed election for the account
  // we can't determine their uuid
  // For Nov release, don't include OJAH in customers-to-inform for this account
  if (!ojahUuid) {
    return customers
  }

  // normal joint account
  // send event to both customers
  let ojahCustomer = {
    authorisingType: 'OJAH',
    uuid: ojahUuid,
    capCisId: individualOwners.find((c) => !c.isInitiatingCustomer).customerId,
  }
  customers.push(ojahCustomer)

  return customers
}

internal.processAccount = function (rawAcct) {
  let {
    accountId, bsb, subProductCode, accountStatus, accountClosedDate, entitlementToShareAccount, customersRetractingApproval,
  } = rawAcct

  let entitled = false
  let failureReasons = []
  if (entitlementToShareAccount && entitlementToShareAccount.entitledToShare === true) {
    if (customersRetractingApproval && customersRetractingApproval.length > 0) {
      entitled = false
      failureReasons = ['Approver stopped sharing']
    } else {
      entitled = true
    }
  } else {
    entitled = false
    failureReasons = (entitlementToShareAccount && entitlementToShareAccount.unentitledReasons) || ['Reason not returned from Authorisation service']
  }

  let acct = {
    accountId,
    bsb,
    subProductCode,
    openStatus: (accountStatus && accountStatus === 'OP') ? 'OPEN' : 'CLOSED',
    entitled,
    failureReasons,
  }
  if (accountClosedDate) acct.closedDate = accountClosedDate

  // for cards
  // accountNumber contains masked cardNumber
  // use redirectionAccountNumber as accountNumber
  // maskedCardNumber is only needed to set maskedAccountNumber in reponse and in PES event
  // use redirectionAccountNumber everywhere else like tokenisation, etc.
  if (accountId.systemId === '153' && rawAcct.redirectionAccountNumber) {
    acct.maskedCardNumber = accountId.accountNumber
    acct.cardProductCode = rawAcct.redirectionAccountProductCode
    acct.redirectionAccountNumber = rawAcct.redirectionAccountNumber

    acct.accountId.accountNumber = rawAcct.redirectionAccountNumber
  }

  return acct
}

internal.processAuth = function (authToken, rawAuth) {
  // convert auth to internal representation to abstract away from auth service
  let auth = { ...rawAuth }

  if (rawAuth.accounts && rawAuth.accounts.length) {
    auth.rawAccounts = rawAuth.accounts
    auth.accounts = []
    for (let rawAcct of rawAuth.accounts) {
      let acct = internal.processAccount(rawAcct)
      acct.customersToInform = internal.getCustomersToInform(rawAcct, authToken)
      auth.accounts.push(acct)
    }
  }

  return auth
}

/**
 * Retrieve, validate, and process authorisation
 *
 * @param {*} ctx - Request context
 * @returns {string} Processed authorisation object
 */
const manageAuthorisation = async function (ctx) {
  const { authToken } = ctx.req
  let authId = authToken.cdr && authToken.cdr.cdr_consent_id
  if (!authId) {
    throw new ServiceError('No consent id in token', {
      id: 'AUTH_SVC_ERR',
      debug: {},
    })
  }

  let rawAuth = await internal.getAuthorisation(ctx, authId)

  let { authorisationStatus, isExpired, expiry } = rawAuth

  if (authorisationStatus !== 'ACTIVATED') {
    throw new ServiceError('Authorisation not activated', {
      id: 'AUTH_NOT_ACTIVE',
      debug: { authorisationStatus },
    })
  }

  if (isExpired !== false) {
    throw new ServiceError('Authorisation expired', {
      id: 'AUTH_EXPIRED',
      debug: { expiry },
    })
  }

  let auth = internal.processAuth(authToken, rawAuth)


  ctx.req.auth = auth // eslint-disable-line no-param-reassign
  ctx.req.eventing = ctx.req.eventing || {} // eslint-disable-line no-param-reassign

  return auth
}


const getCustomerType = function (auth) {
  // all authorisations are for individual customers
  return constants.CUST_TYPE_PERSON
}


const filterOpenAccounts = function (acctList) {
  return acctList.filter((acct) => acct.openStatus === 'OPEN')
}
const filterClosedAccounts = function (acctList) {
  return acctList.filter((acct) => acct.openStatus !== 'OPEN')
}


const isAccountOwned = function (acct, authorisingCustId) {
  // all accounts are considered owned by the authorising customer
  return true
}
const filterOwnedAccounts = function (acctList, authorisingCustId) {
  // return acctList.filter((acct) => isAccountOwned(acct, authorisingCustId))
  // all accounts are considered owned by the authorising customer
  return acctList
}
const filterUnOwnedAccounts = function (acctList, authorisingCustId) {
  // return acctList.filter((acct) => !isAccountOwned(acct, authorisingCustId))
  // all accounts are considered owned by the authorising customer
  return []
}


/**
 * Filters given accounts by provided OB product types
 *
 * @param {array} acctList - Array of accounts to be filtered
 * @param {array} productTypes - Array of product types to be used to filter
 * @returns
 */
const filterAccountsByProdTypes = function (acctList, productTypes) {
  return acctList.filter((acct) => { // eslint-disable-line arrow-body-style
    return productTypes.some((prodType) => { // eslint-disable-line arrow-body-style
      return (acct.accountId.systemId === prodType.systemId)
        && (acct.accountId.productCode === prodType.productCode)
        && (acct.subProductCode === prodType.subProductCode)
    })
  })
}


const getAccountByKey = function (acctKey, auth) {
  if (!acctKey || !auth.accounts) return

  return auth.accounts.find((authAcct) => {
    let authAcctId = authAcct.accountId
    // default to empty object in case it was an invalid account and was not detokenised
    return (authAcctId.systemId === acctKey.systemId)
      && (authAcctId.productCode === acctKey.productCode)
      && (authAcctId.accountNumber === acctKey.accountNumber)
  })
}


module.exports = {
  internal,

  getCustomerType,
  isAccountOwned,

  getAccountByKey,

  filterOpenAccounts,
  filterClosedAccounts,
  filterOwnedAccounts,
  filterUnOwnedAccounts,
  filterAccountsByProdTypes,

  manageAuthorisation,
}

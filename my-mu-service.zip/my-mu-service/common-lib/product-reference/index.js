const SimpleCache = require('../utils/simple-cache')
const ServiceError = require('../error/ServiceError')

const productRefStatic = require('./products.json')

const DEFAULT_TTL = 1440
const CACHE_TTL = parseFloat(process.env.PRODUCT_CACHE_TTL, 10) || DEFAULT_TTL

let internal = {}

/**
 * Function to build data to cache
 *
 * @param {*} ctx
 * @returns {object} Products data to be cached
 * productCategoryMap - hashmap of products by OB category
 * productKeyMap - hashmap of products by product key (systemId:productCode:subProductCode)
 */
internal.buildProductCache = async function (ctx) {
  let products = productRefStatic

  let productCategoryMap = {}
  let productKeyMap = {}

  for (let product of products) {
    // let cat = product.obProductCategory
    let cat = product.openBankingCategory

    // push product to category hash map
    productCategoryMap[cat] = productCategoryMap[cat] || []
    productCategoryMap[cat].push(product)

    // add product to product-id hash map
    productKeyMap[`${product.systemId}:${product.productCode}:${product.subProductCode}`] = product
  }

  return { productKeyMap, productCategoryMap }
}

let productCache = new SimpleCache(internal.buildProductCache, CACHE_TTL)


const getProduct = async function (ctx, { systemId, productCode, subProductCode }) {
  const productKey = `${systemId}:${productCode}:${subProductCode}`
  let productKeyMap

  try {
    let prodCacheData = await productCache.getData(ctx)
    productKeyMap = prodCacheData.productKeyMap
  } catch (err) {
    throw new ServiceError('error getting product reference cache', {
      id: 'PROD_SVC_ERR',
      debug: { cause: err },
    })
  }

  let product = productKeyMap[productKey]
  if (!product) {
    throw new ServiceError(`could not find product with key ${productKey}`, {
      id: 'PROD_SVC_ERR',
      debug: { productKey },
    })
  }
  return product
}

const getProducts = async function (ctx, category) {
  let productCategoryMap
  try {
    let prodCacheData = await productCache.getData(ctx)
    productCategoryMap = prodCacheData.productCategoryMap
  } catch (err) {
    throw new ServiceError('error getting product reference cache', {
      id: 'PROD_SVC_ERR',
      debug: { cause: err },
    })
  }

  let products = productCategoryMap[category]
  if (!products) {
    throw new ServiceError(`could not find products with category '${category}'`, {
      id: 'PROD_SVC_ERR',
      debug: { category },
    })
  }
  return products
}

module.exports = {
  internal,

  getProduct,
  getProducts,
}

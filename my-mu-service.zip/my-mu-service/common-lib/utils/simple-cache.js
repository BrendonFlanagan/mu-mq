/*
  References:
  https://www.mojotech.com/blog/node-js-memory-cache/
*/
const debug = require('debug')('ob-common-lib:utils/simple-cache')


class SimpleCache {
  constructor(cacheBuilder, minutesToLive = 10) {
    this.cacheBuilder = cacheBuilder
    this.millisecondsToLive = minutesToLive * 60 * 1000

    this.cache = undefined
    this.cacheBuildTime = new Date(0)
    this.getData = this.getData.bind(this)
    this.resetCache = this.resetCache.bind(this)
    this.isCacheExpired = this.isCacheExpired.bind(this)
  }

  isCacheExpired() {
    return (this.cacheBuildTime.getTime() + this.millisecondsToLive) < new Date().getTime()
  }

  async getData(...buildParams) {
    if (typeof this.cache === 'undefined' || this.isCacheExpired()) {
      debug('cache has expired, building it again')
      try {
        this.cache = await this.cacheBuilder(...buildParams)
        debug('cache built')
        this.cacheBuildTime = new Date()
        return this.cache
      } catch (builderError) {
        debug('error building cache, return expired data')
        debug(builderError)
        throw builderError
      }
    }

    debug('cache hit')
    return this.cache
  }

  resetCache() {
    this.cache = null
    this.cacheBuildTime = new Date(0)
  }
}

module.exports = SimpleCache

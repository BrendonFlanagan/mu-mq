module.exports = {
  API_HOST_PUBLIC: 'https://api.anz',
  API_HOST_DATA: 'https://cdr.api.anz',
  API_HOST_ADMIN: 'https://admin.cdr.api.anz',

  PAGE_SIZE_DEFAULT: 25,
  PAGE_SIZE_MAX: 1000,
}

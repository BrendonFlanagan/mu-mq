const constants = require('./constants')
const ServiceError = require('../error/ServiceError')


const _str2Num = function (str) {
  return (!isNaN(str)) ? +str : undefined // eslint-disable-line no-restricted-globals
}

const uuid = function (a) {
  /*
  return ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c =>
    (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
  )
  */
  // eslint-disable-next-line no-bitwise, no-mixed-operators
  return a ? (a ^ Math.random() * 16 >> a / 4).toString(16) : ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, uuid)
}

const getIssuerConfig = function () {
  try {
    return JSON.parse(process.env.JWT_ISSUER_MAP)
  } catch (err) {
    let error = new Error('Error parsing JWT_ISSUER_MAP')
    error.originalError = err
    throw error
  }
}

const getPagingInfo = function (req) {
  let query = req.query || {}
  let page = _str2Num(query.page) || 1
  let pageSize = _str2Num(query['page-size']) || constants.PAGE_SIZE_DEFAULT

  if (pageSize > constants.PAGE_SIZE_MAX) {
    let err = new ServiceError('Maximum value for page-size is 1000', {
      id: 'REQ_VALIDATION_ERR',
      clientMessage: 'Invalid value for parameter page-size',
    })
    throw err
  }
  return { page, pageSize }
}


const genLinksSelf = function (originalUrl, type = 'data') {
  const hostBaseMap = {
    data: constants.API_HOST_DATA,
    public: constants.API_HOST_PUBLIC,
    admin: constants.API_HOST_ADMIN,
  }

  const domainName = process.env.OB_DOMAIN_NAME || hostBaseMap[type]
  let urlObj = new URL(originalUrl, domainName)

  let links = { self: urlObj.href }
  return links
}


const genLinksPaginated = function (originalUrl, totalPages) {
  const domainName = process.env.OB_DOMAIN_NAME || constants.API_HOST_DATA
  let urlObj = new URL(originalUrl, domainName)

  let page = _str2Num(urlObj.searchParams.get('page')) || 1

  let links = { self: urlObj.href }
  if (page > 1) {
    urlObj.searchParams.set('page', 1)
    links.first = urlObj.href

    urlObj.searchParams.set('page', page - 1)
    links.prev = urlObj.href
  }
  if (page < totalPages) {
    urlObj.searchParams.set('page', page + 1)
    links.next = urlObj.href

    urlObj.searchParams.set('page', totalPages)
    links.last = urlObj.href
  }
  return links
}


const genResponseHeaders = function (req, opts = {}) {
  let reqHeaders = req.headers || {}
  let resHeaders = {
    'content-type': 'application/json',
    'x-v': req.swag.operation['x-version'],
    'x-fapi-interaction-id': reqHeaders['x-fapi-interaction-id'] || uuid(),
  }
  if (opts.cache) {
    resHeaders['cache-control'] = 'public'
  } else {
    resHeaders['cache-control'] = 'private, no-cache, no-store, max-age=0, no-transform, must-revalidate, proxy-revalidate'
    resHeaders.pragma = 'no-cache'
    resHeaders.expires = '0'
    resHeaders['surrogate-control'] = 'no-store'
  }

  return resHeaders
}



module.exports = {
  getIssuerConfig,

  getPagingInfo,
  genLinksSelf,
  genLinksPaginated,

  genResponseHeaders,

  uuid,
  _str2Num,
}

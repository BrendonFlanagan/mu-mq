const debug = require('debug')('ob-common-lib:error')

const ERROR_TABLE = require('./error-table')
const eventing = require('../eventing')
const { genResponseHeaders } = require('../utils')


let internals = {}

internals.reformatError = function (err) {
  let error = Object.assign({}, err)
  error.message = err.message
  error.stack = err.stack

  // handle documented errors (err.id present in ERROR_TABLE)
  if (ERROR_TABLE[error.id]) {
    let errorId = error.id
    let { status, code, title, detail } = ERROR_TABLE[errorId]
    // override `detail` if clientMessage present in error
    return {
      errorId,
      status,
      body: { errors: [{ code, title, detail: (err.clientMessage || detail) }] },
    }
  }

  // handle other errors here

  // Routing errors
  if (err.status === 404 || err.status === 405) {
    let errorId = 'INT_ROUTING_ERR'
    let { status, code, title, detail } = ERROR_TABLE[errorId]
    return {
      errorId,
      status,
      body: { errors: [{ code, title, detail }] },
    }
  }


  // JWT errors
  if (error.type === 'JwtAuthError') {
    let errorId = 'INT_JWT_VALIDATION_ERR'
    if (error.message === 'Insufficient scopes') {
      errorId = 'INT_JWT_SCOPE_ERR'
    }
    if (error.debug && error.debug.error && error.debug.error.name === 'TokenExpiredError') {
      errorId = 'INT_JWT_EXP_ERR'
    }    
    let { status, code, title, detail } = ERROR_TABLE[errorId]
    return {
      errorId,
      status,
      body: { errors: [{ code, title, detail }] },
    }
  }


  // Request validation
  if (error.type === 'RequestValidationError') {
    let errorId = 'REQ_VALIDATION_ERR'
    let { status, code, title } = ERROR_TABLE[errorId]
    let errors = []
    if (error.context && error.context.errors && Array.isArray(error.context.errors)) {
      error.context.errors.forEach((fld) => {
        errors.push({ code, title, detail: fld.message })
      })
    }
    return {
      errorId,
      status,
      body: { errors },
    }
  }


  // if nothing else matches, send 500 Internal Server Error
  let { status, code, title, detail } = ERROR_TABLE.DEFAULT_INTERNAL_ERROR

  return {
    errorId: 'DEFAULT_INTERNAL_ERROR',
    status,
    body: { errors: [{ code, title, detail }] },
  }
}

const errorHandler = async function (context, err) {
  let { req } = context
  debug(JSON.stringify(err, 0, 2))

  let { errorId, status, body } = internals.reformatError(err)

  context.req.eventing = context.req.eventing || {} // eslint-disable-line no-param-reassign
  context.req.eventing.error = err // eslint-disable-line no-param-reassign
  context.req.eventing.error.errorId = errorId // eslint-disable-line no-param-reassign

  // TODO
  // if eventing fails during error
  // ignore it
  try {
    await eventing.sendPesEvent(context)
  } catch (eventingErr) {
    debug(eventingErr)
  }

  let headers = genResponseHeaders(req)

  return { status, headers, body }
}

const errorHandlerNoEventing = async function (context, err) {
  let { req } = context
  debug(JSON.stringify(err, 0, 2))

  let { status, body } = internals.reformatError(err)

  let headers = genResponseHeaders(req)

  return { status, headers, body }
}

module.exports = {
  internals,
  errorHandler,
  errorHandlerNoEventing,
}

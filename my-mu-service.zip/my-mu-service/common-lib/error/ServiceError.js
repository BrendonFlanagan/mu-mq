class ServiceError extends Error {
  constructor(message, properties = {}, options = {}) {
    super(message)
    this.name = this.constructor.name
    Error.captureStackTrace(this, this.constructor) // after setting name to include name in stack

    if (properties) {
      Object.assign(this, properties)
    }
  }
}

module.exports = ServiceError

module.exports = {
  // Uncaught internal errors
  DEFAULT_INTERNAL_ERROR: {
    status: 500,
    code: '0000',
    title: 'Internal Error',
    detail: 'Internal Server Error',
  },

  // Routing errors
  INT_ROUTING_ERR: {
    status: 500,
    code: '0000', // TODO
    title: 'Internal Error',
    detail: 'Internal Server Error',
  },


  INT_JWT_SCOPE_ERR: {
    status: 403,
    code: '0000',
    title: 'Insufficient Scopes',
    detail: 'Requester does not have permission to access the resource',
  },
  INT_JWT_VALIDATION_ERR: {
    status: 500,
    code: '0000',
    title: 'Internal Error',
    detail: 'Internal Server Error',
  },
  INT_JWT_EXP_ERR: {
    status: 401,
    code: '0000',
    title: 'Token Expired',
    detail: 'Supplied access token has expired',
  },


  REQ_VALIDATION_ERR: {
    status: 422,
    code: '0000',
    title: 'Invalid Request',
    detail: 'Invalid Request',
  },


  // Authorisation errors
  AUTH_SVC_ERR: {
    status: 500,
    code: '0000',
    title: 'Internal Error',
    detail: 'Internal Server Error',
  },
  AUTH_NOT_ACTIVE: {
    status: 500,
    code: '0000',
    title: 'Internal Error',
    detail: 'Internal Server Error',
  },
  AUTH_EXPIRED: {
    status: 500,
    code: '0000',
    title: 'Internal Error',
    detail: 'Internal Server Error',
  },


  ACCT_ID_INVALID: {
    status: 400,
    code: '0001',
    title: 'Account Invalid',
    detail: 'The account id requested is invalid',
  },

  ACCT_NOT_AUTHORISED: {
    status: 404,
    code: '0000',
    title: 'Account Not Found',
    detail: 'Account Not Found',
  },
  ACCT_NOT_ENTITLED: {
    status: 403,
    code: '0000',
    title: 'Account Not Entitled',
    detail: 'Account Not Entitled',
  },
  TRN_ID_INVALID: {
    status: 400,
    code: '0001',
    title: 'Transaction Id Invalid',
    detail: 'The transaction id requested is invalid',
  },

  /*
  ACCOUNT_INVALID: {
    status: 400,
    code: '0001',
    title: 'Account Invalid',
    detail: 'The account supplied is invalid',
  },
  */


  // Id Permanence errors
  ID_SVC_ERR: {
    status: 500,
    code: '0000', // TODO
    title: 'Internal Error',
    detail: 'Internal Server Error',
  },

  // Data retrieval errors
  MEDIATION_API_ERR: {
    status: 500,
    code: '0000', // TODO
    title: 'Internal Error',
    detail: 'Internal Server Error',
  },

  // Id Permanence errors
  EVENT_SVC_ERR: {
    status: 500,
    code: '0000', // TODO
    title: 'Internal Error',
    detail: 'Internal Server Error',
  },
}

const ServiceError = require('../error/ServiceError')
const authSvc = require('../authorisation')
const prodRef = require('../product-reference')


let internal = {}

internal.filterByOpenStatus = function (acctList, openStatus) {
  if (typeof openStatus === 'undefined') return acctList

  switch (openStatus) {
    case 'OPEN': return authSvc.filterOpenAccounts(acctList)
    case 'CLOSED': return authSvc.filterClosedAccounts(acctList)
    case 'ALL': return acctList
    default: return acctList
  }
}

internal.filterByIsOwned = function (acctList, isOwned) {
  if (typeof isOwned === 'undefined') return acctList

  switch (isOwned) {
    case 'true': return authSvc.filterOwnedAccounts(acctList)
    case 'false': return authSvc.filterUnOwnedAccounts(acctList)
    default: return acctList
  }
}

internal.filterByProdCat = async function (ctx, acctList, productCategory) {
  if (typeof productCategory === 'undefined') return acctList

  // let productCache = await prodRef.getProductCache(ctx)
  // let applicableProductTypes = prodRef.getProductsByCategory(productCategory, productCache)
  let applicableProductTypes = await prodRef.getProducts(ctx, productCategory)

  return authSvc.filterAccountsByProdTypes(acctList, applicableProductTypes)
}



const processBulkAccts = async function (ctx, auth) {
  let queryParams = ctx.req.query || {}

  let inScopeAccts = auth.accounts
  inScopeAccts = internal.filterByOpenStatus(inScopeAccts, queryParams['open-status'])
  inScopeAccts = internal.filterByIsOwned(inScopeAccts, queryParams['is-owned'])
  inScopeAccts = await internal.filterByProdCat(ctx, inScopeAccts, queryParams['product-category'])

  // TODO finalize context var
  ctx.req.eventing.accounts = inScopeAccts // eslint-disable-line no-param-reassign
  // ctx.req.obContext.eventing.accounts = inScopeAccts // eslint-disable-line no-param-reassign

  let entitledInScopeAccts = inScopeAccts.filter((acct) => acct.entitled)

  return entitledInScopeAccts
}

const processMultiAccts = function (ctx, auth, reqAcctKeys) {
  let inScopeAccts = []

  for (let acctKey of reqAcctKeys) {
    let authAcct = authSvc.getAccountByKey(acctKey, auth)
    if (authAcct) {
      inScopeAccts.push(authAcct)
    } else {
      // account was detokenised but not in auth, ignore it
      // inScopeAccts.push({ accountId: acctKey, valid: false, failureReasons: ['Account not authorised'] })
    }
  }

  // TODO finalize context var
  ctx.req.eventing.accounts = inScopeAccts // eslint-disable-line no-param-reassign
  // ctx.req.obContext.eventing.accounts = inScopeAccts // eslint-disable-line no-param-reassign

  let entitledInScopeAccts = inScopeAccts.filter((acct) => acct.entitled)

  return entitledInScopeAccts
}

const processSingleAcct = function (ctx, auth, reqAcctKey) {
  if (!reqAcctKey) {
    ctx.req.eventing = ctx.req.eventing || {}
    ctx.req.eventing.accounts = [] // TODO remove once switched to obContext // eslint-disable-line no-param-reassign
    // ctx.req.obContext.eventing.accounts = [] // eslint-disable-line no-param-reassign
    let err = new ServiceError('Invalid account id', {
      id: 'ACCT_ID_INVALID',
      debug: { reason: 'id permanence did not return valid key' },
    })
    throw err
  }

  let inScopeAcct = authSvc.getAccountByKey(reqAcctKey, auth)
  if (!inScopeAcct) {
    ctx.req.eventing.accounts = [] // eslint-disable-line no-param-reassign
    throw new ServiceError('Account not authorised', {
      id: 'ACCT_NOT_AUTHORISED',
      debug: { reason: 'detokenised account key not found in authorised accounts' },
    })
  }

  // TODO finalize context var
  ctx.req.eventing.accounts = [inScopeAcct] // eslint-disable-line no-param-reassign
  // ctx.req.obContext.eventing.accounts = [inScopeAcct] // eslint-disable-line no-param-reassign

  if (!inScopeAcct.entitled) {
    throw new ServiceError('Account not entitled', {
      id: 'ACCT_NOT_ENTITLED',
      debug: { reason: '' },
    })
  }

  return inScopeAcct
}

// ///////////////////////////////////////////////////

module.exports = {
  internal,

  processSingleAcct,
  processMultiAccts,
  processBulkAccts,
}

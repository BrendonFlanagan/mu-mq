const httpConnector = require('@mu-eis/mu-connector-http')

const ServiceError = require('../error/ServiceError')
const { uuid } = require('../utils')


let internal = {}

internal.emitPesEvent = async function (ctx, eventData) {
  let { req } = ctx
  let { config } = req.app.locals
  let props = config.envProperties
  let timeout = parseInt(process.env.EVENTING_TIMEOUT, 10) || 10000

  let httpConnOpts = {
    name: 'emit-event',
    method: 'post',
    baseUrl: props.EVENTING_ENDPOINT,
    url: '/events',
    headers: {
      Authorization: req.headers.authorization,
    },
    body: eventData.body,
    timeout, // TODO
    tls: {
      strict: false, // TODO: remove after testing
    },
  }
  let { error, status, body } = await httpConnector(httpConnOpts, ctx)

  if (error) {
    throw new ServiceError('Error while calling Eventing Adaptor service', {
      id: 'EVENT_SVC_ERR',
      // debug: { cause: error.toString() },
      debug: { cause: error },
    })
  }
  if (status !== 200) {
    throw new ServiceError('Non 2xx response from Eventing Adaptor service', {
      id: 'EVENT_SVC_ERR',
      debug: { status },
    })
  }
  return { status, body }
}

internal.genCommonEventProps = function (ctx) {
  let { req } = ctx

  let cdrData = (req.authToken && req.authToken.cdr) || {}
  let eventingCtx = req.eventing || {}

  let apiOutcome = 'success'
  let apiFailureReasons = []

  if (eventingCtx.error) {
    apiOutcome = 'failure'
    apiFailureReasons = [(eventingCtx.error.errorId || eventingCtx.error.message)]
  }

  let commonProps = {
    cdrConsentId: cdrData.cdr_consent_id,
    softwareProductId: cdrData.software_product_id,
    endpoint: `${req.method} ${req.originalUrl}`,
    endpointName: req.swag.operation.operationId || 'UNKNOWN',
    outcome: apiOutcome,
    failureReasons: apiFailureReasons,
    // customerUUID: '',
    // payeeId: eventingCtx.payeeId || null,
    // transactionId: eventingCtx.transactionId || null,
  }
  return commonProps
}

/*
internal.genEventMeshSubject = function (customer) {
  if (customer.authorisingType === 'INITIATOR') {
    return {
      subjectType: { 'com.anz.csp.pes.PartyIdType': 'CRN' },
      subjectId: customer.crn,
    }
  }
  return {
    subjectType: { 'com.anz.csp.pes.PartyIdType': 'CAP_CIS_ID' },
    subjectId: customer.capCisId,
  }
}

internal.genEventKey = function (customer) {
  if (customer.authorisingType === 'INITIATOR') {
    return `CRN~${customer.crn}`
  }
  return `CAP_CIS_ID~${customer.capCisId}`
}
*/

internal.genCommonEventMeshHeader = function (ctx) {
  let { req } = ctx
  let spanCtx = (req.span && req.span.context()) || req.auditMeta.tracing || {}

  let eventMeshHeader = {
    eventUUID: '',
    subject: {},
    source: 'ob-services',
    occurrenceDateTime: (new Date()).getTime(),
    traceId: spanCtx.traceId,
    spanId: spanCtx.spanId,
    parentSpanId: (spanCtx.parentId) ? { string: spanCtx.parentId } : null,
    correlationId: null,
    hierarchy: 'AU/RETAIL',
    ignore: false,
    retryCounter: 0,
    expiryDateTime: null,
  }

  return eventMeshHeader
}

internal.genPesBase = function (ctx) {
  let { headers } = ctx.req || {}

  // initiator: {
  //   'com.anz.csp.pes.Initiator': {
  //     initiatorType: { 'com.anz.csp.pes.InitiatorType': 'CRN' },
  //     initiatorId: customerCrn,
  //   },
  // },

  let pesBase = {
    header: {},
    partyUUID: null,
    externalSessionId: null,
    externalTaskId: null,
    initiator: null,
    location: {
      'com.anz.csp.pes.DigitalLocation': {
        ipAddress: headers['x-fapi-customer-ip-address'] || headers['x-forwarded-for'] || '',
        physicalLocation: '',
      },
    },
    applicationId: headers['anz-application-id'] || headers['x-application-context'] || 'ob-tpp',
    assistedBy: { 'com.anz.csp.pes.AssistingChannel': { assistingChannelName: 'open-banking' } },
    eventData: null,
    eventSource: null,
    contentTags: null,
  }

  return pesBase
}

internal.genEventKey = function (customer) {
  if (customer.authorisingType === 'INITIATOR') return `CRN~${customer.crn}`

  return `CAP_CIS_ID~${customer.capCisId}`
}
internal.genEventMeshSubject = function (customer) {
  if (customer.authorisingType === 'INITIATOR') {
    return {
      subjectType: { 'com.anz.csp.pes.PartyIdType': 'CRN' },
      subjectId: customer.crn,
    }
  }

  return {
    subjectType: { 'com.anz.csp.pes.PartyIdType': 'CAP_CIS_ID' },
    subjectId: customer.capCisId,
  }
}

internal.genSplitEventData = function (opts) {
  let { pesBase, commonEventMeshHeader, commonEventProperties, accounts = [], customer, eventUUID = uuid() } = opts

  let eventKey = internal.genEventKey(customer)
  let subject = internal.genEventMeshSubject(customer)

  let meta = {
    type: customer.authorisingType,
    key: eventKey,
  }

  let header = {
    ...commonEventMeshHeader,
    eventUUID,
    subject,
  }
  let properties = {
    ...commonEventProperties,
    // customerUUID: customer.uuid,
    accounts,
  }

  let payload = {
    ...pesBase,
    header,
    properties,
  }

  return { meta, payload }
}

internal.genCombinedEventData = function (opts) {
  let { pesBase, commonEventMeshHeader, customer, events, eventUUID = uuid() } = opts

  let eventKey = internal.genEventKey(customer)
  let subject = internal.genEventMeshSubject(customer)

  let meta = {
    key: eventKey,
  }

  let header = {
    ...commonEventMeshHeader,
    eventUUID,
    subject,
  }

  let payload = {
    ...pesBase,
    header,
    properties: events,
  }

  return { meta, payload }
}

internal.genCustomerAccountMap = function (accounts) {
  let customerMap = {}

  for (let acct of accounts) {
    let acctOutcome = 'success'
    let acctFailureReasons = []

    // if (eventingCtx.error) {
    //   acctOutcome = 'failure'
    // }

    // eslint-disable-next-line no-lonely-if
    if (acct.failureReasons && acct.failureReasons.length) {
      acctOutcome = 'failure'
      acctFailureReasons = acct.failureReasons
    }

    let accountNumber = (acct.accountId.systemId === '153')
      ? acct.maskedCardNumber
      : (acct.accountId && acct.accountId.accountNumber)

    let acctInfo = {
      accountNumber: accountNumber || 'UNKNOWN',
      bsbCode: acct.bsb || 'UNKNOWN',
      // productCode: acct.accountId.productCode,
      // subProductCode: acct.subProductCode,
      outcome: acctOutcome,
      failureReasons: acctFailureReasons,
    }

    // add account to customers
    for (let cust of acct.customersToInform) {
      customerMap[cust.uuid] = customerMap[cust.uuid] || {
        customer: cust,
        accounts: [],
      }
      customerMap[cust.uuid].accounts.push(acctInfo)
    }
  }

  return customerMap
}


internal.genPesEvent = function (ctx, additionalProps = {}) {
  let { req } = ctx
  let { authToken } = req

  let eventingCtx = req.eventing || {}
  eventingCtx.payeeId = additionalProps.payeeId
  eventingCtx.transactionId = additionalProps.transactionId

  let initiatingCustomer = {
    authorisingType: 'INITIATOR',
    crn: authToken.crns[0],
    uuid: authToken.sub,
  }
  let pesBase = internal.genPesBase(ctx)
  let commonEventMeshHeader = internal.genCommonEventMeshHeader(ctx)
  let commonEventProperties = internal.genCommonEventProps(ctx)

  let events = []

  // generate split event data
  if (!eventingCtx.accounts) {
    // if eventing context does not have accounts list
    // send event only to Initiator
    let splitEventData = internal.genSplitEventData({
      pesBase,
      commonEventMeshHeader,
      commonEventProperties,
      customer: initiatingCustomer,
      accounts: [],
    })
    events.push(splitEventData)
  } else {
    // if eventing context has accounts list
    // determine OJAHs, send events to Initiator and OJAHs
    let customerAccountMap = internal.genCustomerAccountMap(eventingCtx.accounts)
    for (let custUuid in customerAccountMap) {
      let { customer, accounts } = customerAccountMap[custUuid]
      let splitEventData = internal.genSplitEventData({
        pesBase,
        commonEventMeshHeader,
        commonEventProperties,
        customer,
        accounts,
      })
      events.push(splitEventData)
    }
  }

  let combinedEventData = internal.genCombinedEventData({
    pesBase,
    commonEventMeshHeader,
    customer: initiatingCustomer,
    events,
  })

  const adaptorBody = {
    records: [
      {
        key: combinedEventData.meta.key,
        value: combinedEventData.payload,
      },
    ],
  }

  return adaptorBody
}


const sendPesEvent = async function (ctx, additionalProps = {}) {
  let eventBody = internal.genPesEvent(ctx, additionalProps)

  // await internal.emitPesEvent(ctx, { body: eventBody })
  // return eventBody

  // temporary fix
  // use existing eventing adaptor with multiple records
  let splitEvents = eventBody.records[0].value.properties
  let eventRecords = splitEvents.map((ev) => {
    let { key } = ev.meta
    let value = ev.payload
    return { key, value }
  })
  eventBody = { records: eventRecords }
  await internal.emitPesEvent(ctx, { body: eventBody })

  return eventBody
}


module.exports = {
  internal,
  sendPesEvent,
}

/*
  // let stream = require('fs').createWriteStream('./events.json', { flags: 'a' })
  // stream.write(eventBody.records[0].value.externalTraceId + '\n------------------\n' + JSON.stringify(eventBody.records[0].value, 0, 2) + '\n\n')
*/

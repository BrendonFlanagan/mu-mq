const httpConnector = require('@mu-eis/mu-connector-http')
const ServiceError = require('../error/ServiceError')

const genKeySeed = function (authToken) {
  let uuid = authToken.sub
  let swId = authToken.cdr.software_product_id
  return `${swId}_${uuid}`
}

const tokenise = async function (context, keySeed, items) {
  let { req } = context
  let { config } = req.app.locals
  let props = config.envProperties
  let timeout = parseInt(process.env.ID_PERM_TIMEOUT, 10) || 10000

  let tokeniseBody = { keySeed, items }

  let tokeniseOpts = {
    name: 'tokenise',
    method: 'post',
    baseUrl: props.ID_ENDPOINT,
    url: '/idpermanence/tokenise',
    headers: {},
    body: tokeniseBody,
    timeout,
  }

  let { error, status, body } = await httpConnector(tokeniseOpts, context)

  if (error) {
    throw new ServiceError('Error while calling Id Permanence service while tokenising', {
      id: 'ID_SVC_ERR',
      debug: { cause: error },
    })
  }
  if (status !== 200) {
    throw new ServiceError('Non 2xx response from Id Permanence service while tokenising', {
      id: 'ID_SVC_ERR',
      debug: { status },
    })
  }

  return body
}

const detokenise = async function (context, keySeed, tokens) {
  let { req } = context
  let { config } = req.app.locals
  let props = config.envProperties
  let timeout = parseInt(process.env.ID_PERM_TIMEOUT, 10) || 10000

  let detokeniseBody = { keySeed, tokens }

  let detokeniseOpts = {
    name: 'detokenise',
    method: 'post',
    baseUrl: props.ID_ENDPOINT,
    url: '/idpermanence/detokenise',
    headers: {},
    body: detokeniseBody,
    timeout,
  }

  let { error, status, body } = await httpConnector(detokeniseOpts, context)

  if (error) {
    throw new ServiceError('Error while calling Id Permanence service while detokenising', {
      id: 'ID_SVC_ERR',
      debug: { cause: error },
    })
  }
  if (status !== 200) {
    throw new ServiceError('Non 2xx response from Id Permanence service while detokenising', {
      id: 'ID_SVC_ERR',
      debug: { status },
    })
  }

  return body
}

module.exports = {
  genKeySeed,
  tokenise,
  detokenise,
}
